﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _16_prakt
{
    public partial class Form1 : Form
    {
        int[] massiv;
        int[] massiv3;
        int[] massiv4;
        Class1 clas = new Class1();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            if (int.TryParse(textBox1.Text, out int nn))
            {
                if (Convert.ToInt32(textBox1.Text) >= 0)
                {
                    StreamWriter sw = new StreamWriter("file.txt");
                    massiv = clas.Pynkt1(Convert.ToInt32(textBox1.Text));
                    for (int i = 0; i < massiv.Length; i++)
                    {
                        listBox1.Items.Add(massiv[i]);
                        sw.WriteLine(massiv[i]);
                    }
                    sw.Close();
                }
                else MessageBox.Show("Значение должно быть больше 0");
            }
            else MessageBox.Show("Введите корректно");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            if (int.TryParse(textBox2.Text, out int nn))
            {
                if (Convert.ToInt32(textBox2.Text) >= 0)
                {
                    int n = Convert.ToInt32(textBox2.Text);
                    if (n < 0 || n >= massiv.Length)
                    {
                        MessageBox.Show("Вы вышли за границы массивы");
                    }
                    else listBox2.Items.Add(clas.Pynkt2(massiv, n));
                }
                else MessageBox.Show("Значение должно быть больше 0");
            }
            else MessageBox.Show("Введите zeкорректно");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int count = 0;
            int[] mas2 = new int[massiv.Length];
            listBox3.Items.Clear();
            if (comboBox1.Text != "")
            {
                if (File.Exists("file.txt"))
                {
                    StreamReader sr = new StreamReader("file.txt");

                    while (!sr.EndOfStream)
                    {
                        mas2[count] = Convert.ToInt32(sr.ReadLine());
                        count++;
                    }
                    sr.Close();
                    massiv3 = clas.Pynkt1(count);
                    massiv4 = clas.Pynkt3(mas2, massiv3, comboBox1.Text);

                    for (int i = 0; i < massiv.Length; i++)
                    {
                        listBox3.Items.Add(massiv3[i]);
                    }
                }
                else MessageBox.Show("Файл не найден");
            }
            else MessageBox.Show("Выберите действие");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox4.Items.Clear();

            if (int.TryParse(textBox3.Text, out int nn))
            {
                if (Convert.ToInt32(textBox3.Text) >= 0)
                {
                    int n = Convert.ToInt32(textBox3.Text);
                    if (n < 0 || n >= massiv.Length)
                    {
                        MessageBox.Show("Вы вышли за границы массивы");
                    }
                    else
                    {
                        int[] m = clas.Pynkt4(massiv, n);

                        for (int i = 0; i < m.Length; i++)
                        {
                            listBox4.Items.Add(m[i]);
                        }
                    }
                }
                else MessageBox.Show("Значение должно быть больше 0");
            }
            else MessageBox.Show("Введите корректно");
        }
    }

}   

