﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16_prakt
{
    internal class Class1
    {
        private int a { get; set; }
        Random rnd = new Random();
        public int[] Pynkt1(int n)
        {
            a = n;
            int[] mas = new int[a];

            for (int i = 0; i < n; i++)
            {
                mas[i] = rnd.Next(-30, 50);
            }
            return mas;
        }
        public int Pynkt2(int[] mas, int n)
        {
            return mas[n];
        }
        public int[] Pynkt3(int[] mas1, int[] mas2, string a)
        {
            int[] mas3 = new int[mas1.Length];
            switch (a)
            {
                case "*":
                    for (int i = 0; i < mas1.Length; i++)
                    {
                        mas3[i] = mas1[i] * mas2[i];
                    }
                    break;
                case "+":
                    for (int i = 0; i < mas1.Length; i++)
                    {
                        mas3[i] = mas1[i] + mas2[i];
                    }
                    break;
                case "-":
                    for (int i = 0; i < mas1.Length; i++)
                    {
                        mas3[i] = mas1[i] - mas2[i];
                    }
                    break;
                

            }
            return mas3;
        }
        public int[] Pynkt4(int[] mas, int n)
        {
            int count = 0;
            for (int i = n; i < mas.Length; i++)
            {
                count++;
            }
            int[] mass = new int[count];

            int count1 = 0;
            for (int i = n; i < mas.Length; i++)
            {
                mass[count1] = mas[i];
                count1++;
            }
            return mass;
        }
    }
}
